#!/usr/bin/python3

fg_l7_categories = {
    "Business",
    "Cloud.IT",
    "Collaboration",
    "Email",
    "Game",
    "General.Interest",
    "Industrial",
    "Mobile",
    "Network.Service",
    "P2P",
    "Proxy",
    "Remote.Access",
    "Social.Media",
    "Storage.Backup",
    "Update",
    "Video/Audio",
    "VoIP",
    "Web.Client",
    "Unknown Applications",
}

service_category = {
    "General",
    "Web Access",
    "File Access",
    "Email",
    "Network Services",
    "Authentication",
    "Remote Access",
    "Tunneling",
    "VoIP, Messaging & Other Applications",
    "Web Proxy",
    "VPN",
    "TrueConf",
}

